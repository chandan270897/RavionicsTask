package Com.mahi.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet 
{
	public void service(HttpServletRequest reqs , HttpServletResponse resp) throws IOException
	{
		String Name=reqs.getParameter("name");
		String pass=reqs.getParameter("pass");
		
		
		String qry="select * from internsala.logintest";
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=CHANDAN100");
			PreparedStatement ps=con.prepareStatement(qry);
			ResultSet rs= ps.executeQuery();
			PrintWriter out=resp.getWriter();
			
				while(rs.next())
				{
					if(Name.equals(rs.getString(2)) && pass.equals(rs.getString(3)))
					{
						out.println("Welcome "+Name);
					}
				}
		}
		catch (Exception e) 
		{
		e.printStackTrace();	
		}
	}
}
