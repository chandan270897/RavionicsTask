package Com.mahi.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterServlet extends HttpServlet
{
	public void service(HttpServletRequest reqs , HttpServletResponse resp) throws IOException
	{
		String Id=reqs.getParameter("id");
		String Name=reqs.getParameter("name");
		String Pass=reqs.getParameter("pass");
		
		String qry="insert into internsala.logintest value(?,?,?)";
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=CHANDAN100");
			PreparedStatement ps=con.prepareStatement(qry);
			ps.setString(1, Id);
			ps.setString(2, Name);
			ps.setString(3, Pass);
			ps.executeUpdate();
			resp.sendRedirect("Login.html");
		}
		catch (Exception e) 
		{
		e.printStackTrace();	
		}
	}
}
